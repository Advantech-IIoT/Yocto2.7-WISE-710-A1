#include <stdarg.h>
#include <termio.h>
#include <sys/timeb.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <stdlib.h>

//Rfid.c
int RFID_OpenReader(char Com[]);
int RFID_CloseReader();
int RFID_GetAPIVersionString(char OutVersion[]);
int RFID_FWVersion(char OutVersion[]);
int RFID_WorkingType(int type,int Half_Power);
int RFID_AntennaControl(int Select);

//15693
int SetProtocol15693(char flag[],int Half_Power);
int Inventory15693(char flag[],char AFI[],char OutUID[]);
int ReadSingleBlock(char block[],char flag[],char AddressUID[],char OutData[]);
int WriteSingleBlock(char block[],char flag[],char AddressUID[],char Data[]);
int WriteAFI(char flag[],char AddressUID[],char Data[]);
int WriteDSFID(char flag[],char AddressUID[],char Data[]);
int TagStayQuiet(char flag[],char AddressUID[]);
int TagSelect(char flag[],char AddressUID[]);
int TagResetToReady(char flag[],char AddressUID[]);
int LockAFI(char flag[],char AddressUID[]);
int LockDSFID(char flag[],char AddressUID[]);
int TagSystemInfo(char flag[],char AddressUID[],char OutData[]);
int RFID_ISO15693LockBlock(char flag[], char block[]);

//14443A
int RFID_Get14443AUID(char OutUID[]);
int ReadMifareBlock(char Key[], char block[], char OutData[]);
int WriteMifareBlock(char Key[], char block[], char Data[]);

int RFID_ReadUltraLightBlock(char block[],char OutData[]);
int RFID_WriteUltraLightBlock(char block[],char Data[]);

int RFID_WriteMifareOneBlock(int Keytype, char Key[], char block[], char Data[],char AUID[]);
int RFID_ReadMifareOneBlock(int Keytype, char Key[], char block[], char OutData[],char AUID[]);
int RFID_OpenCard(char OutUID[]);




//14443B
int GetUid14443B(int type,char OutUID[]);
int SRIX4KChipID(char OutID[]);
int SRIX4KReadBlock(char block[],char OutData[]);
int SRIX4KWriteBlock(char block[],char Data[]);
