#include "rfid.h"

void Usage(const char *appstr) 
{
	printf("Usage: %s <DEVICE> <TEST-TYPE> \n", appstr);
	printf("Exp: %s /dev/ttyUSB0 0 \n", appstr);
	printf("<TEST-TYPE> \n");
	printf("  99 - get API version \n");
	printf("   0 - get FW version \n");				
	printf("   1 - get 14443A UID \n");				
	printf("  10 - read 14443A, block: 04 \n");
	printf("  11 - write 14443A, block: 04, data: 00000000000000000000000000000000 \n");											
	printf("  12 - write 14443A, block: 04, data: 12345678901234567890123456789012 \n");											
	printf("   6 - get 14443B UID \n");
	printf("   9 - read 14443B, block: 07 \n");
	printf("   7 - write 14443B, block: 07, data: 12345678 \n");
	printf("   8 - write 14443B, block: 07, data: 00000000 \n");
	printf("   2 - get 15693 UID \n");
	printf("   5 - read 15693, block: 01 \n");
	printf("   3 - write 15693, block: 01(40), data: 12345678 \n");
	printf("   4 - write 15693, block: 01(40), data: 00000000 \n");
	printf("  20 - write 15693, block: 01(00), data: 12345678 \n");
	printf("  21 - write 15693, block: 01(00), data: 00000000 \n");
	printf("  22 - lock 15693 NXP tag \n");
	printf("  23 - lock 15693 Ti tag \n");
	printf("  15 - read UltraLight, block: 07 \n");
	printf("  13 - write UltraLight, block: 07, data: 12345678 \n");											
	printf("  14 - write UltraLight, block: 07, data: 00000000 \n");											
	printf("  16 - antenna ON\n");							
	printf("  17 - antenna OFF\n");							
	printf("  18 - loading test, looping 'get 14443A UID' 5 secs \n");
	printf("  19 - loading test, looping 'get 14443A UID + read + write' 5 secs \n");
	printf("  24 - loading test, get 14443A UID 100 times \n");
}

int main(int argc, char *argv[])
{	 

	int ContorlA = 0,count = 0,Time = 0,Err = 0;
	int i,err,j;
	unsigned char UID[24],Data[64],tmp[24],Data32[64];
	memset(UID, 0x0, 24);  
	memset(Data, 0x0, 64);  		
	memset(tmp, 0x0, 24);  	

	if (argc != 3) {
		Usage(argv[0]);
		return 0;
	}

	if (RFID_OpenReader(argv[1]) == 0) {
		printf("OpenComPort OK \n");
	} else {	
		printf("OpenComPort Error !! : \n");
	}

	ContorlA = atoi(argv[2]);     		

	switch (ContorlA) {		
	case 99: //GetAPIVersion
		memset(tmp, 0x0, 24);  					
		RFID_GetAPIVersionString(tmp);
		printf("APIVersion : ");
		printf("%s\n", tmp);				
		break;		

	case 0: //GetFWVersion
		memset(tmp, 0x0, 24);  					
		RFID_FWVersion(tmp);
		printf("FWVersion : ");
		printf("%s\n", tmp);				
		break;		

	case 1:// Get 14443A UID
		RFID_WorkingType(1,0);       // RFID_WorkingType(Type,Power);		Type0:15693   Type1:14443A    Type2:14443B	Type3:Felica	 1=Half_Power   0=Full_Power
		RFID_Get14443AUID(UID);
		printf("14443A UID : ");
		printf("%s\n", UID);					
		break;				

	case 2: // Get 15693 UID	
		RFID_WorkingType(0,0);  	    // RFID_WorkingType(Type,Power);		Type0:15693   Type1:14443A    Type2:14443B	Type3:Felica	 1=Half_Power   0=Full_Power
		Inventory15693(0,0,UID);		// Get 15693 UID	
		printf("15693 UID : ");
		printf("%s\n", UID);						
		break;													

	case 3: // Write 15693 Block 01 Data 12345678	
		RFID_WorkingType(0,0);
		WriteSingleBlock("01","40",0,"12345678");	
		printf("WriteSingleBlock : 12345678 \n");
		break;

	case 4: // Write 15693 Block 01 Data 00000000
		RFID_WorkingType(0,0);
		WriteSingleBlock("01","40",0,"00000000");		
		printf("WriteSingleBlock : 00000000 \n");
		break;

	case 5: // Read 15693 Block 01					
		RFID_WorkingType(0,0);
		memset(Data, 0x0, 64);  	
		ReadSingleBlock("01","00",0,Data);
		printf("Block Data : ");
		printf("%s\n", Data);					
		break;								

	case 6://Read 14443B UID
		RFID_WorkingType(2,0);       // RFID_WorkingType(2,0);		Type0:15693   Type1:14443A    Type2:14443B   Type3:Felica		 1=Half_Power   0=Full_Power
		memset(tmp, 0x0, 24);
		SRIX4KChipID(tmp);
		printf("SRIX4KChipID : ");
		printf("%s\n", tmp);		
		memset(tmp, 0x0, 24);
		GetUid14443B(3,tmp);
		printf("SRIX4KUID : ");
		printf("%s\n", tmp);		
		break;

	case 7://Write 14443B Block Data   
		RFID_WorkingType(0,0);                                     
		RFID_WorkingType(2,0);       // RFID_WorkingType(2,0);		Type0:15693   Type1:14443A    Type2:14443B   Type3:Felica		 1=Half_Power   0=Full_Power
		memset(tmp, 0x0, 24);
		SRIX4KChipID(tmp);
		printf("SRIX4KChipID : ");
		printf("%s\n", tmp);		

		memset(Data, 0x0, 64);  	
		if (SRIX4KWriteBlock("07","12345678") == 0)
			printf("Write SRIX4K 07 Data 12345678\n");								
		else
			printf("Write SRIX4K 07 Error !\n");


		break;				

	case 8://Write 14443B Block Data
		RFID_WorkingType(0,0);
		RFID_WorkingType(2,0);     // RFID_WorkingType(2,0);		Type0:15693   Type1:14443A    Type2:14443B   Type3:Felica		 1=Half_Power   0=Full_Power
		memset(tmp, 0x0, 24);
		SRIX4KChipID(tmp);
		printf("SRIX4KChipID : ");
		printf("%s\n", tmp);		

		memset(Data, 0x0, 64);  	
		if (SRIX4KWriteBlock("07","00000000") == 0)
			printf("Write SRIX4K 07 Data 00000000\n");									
		else
			printf("Write SRIX4K 07 Error !\n");	
		break;				

	case 9://Read 14443B Block Data
		RFID_WorkingType(2,0);       // RFID_WorkingType(2,0);		Type0:15693   Type1:14443A    Type2:14443B   Type3:Felica		 1=Half_Power   0=Full_Power
		memset(tmp, 0x0, 24);
		SRIX4KChipID(tmp);
		printf("SRIX4KChipID : ");
		printf("%s\n", tmp);		

		memset(Data, 0x0, 64);  	
		SRIX4KReadBlock("07",Data);
		printf("SRIX4K 07 Data  : ");
		printf("%s\n", Data);							
		break;				

	case 10://Read 14443A Block Data					
		memset(Data32, 0x0, 64);  	
		err = ReadMifareBlock("FFFFFFFFFFFF","04",Data32);
		if (err != 0)
		{
			printf("Read 14443A Block Fail ! \n ");
			return 0;
		}
		printf("14443A 04 Data  : ");
		printf("%s\n", Data32);							
		break;				

	case 11://Write 14443A Block Data						
		err = WriteMifareBlock("FFFFFFFFFFFF","04","00000000000000000000000000000000");
		if (err != 0)
		{
			printf("Write 14443A Block Fail ! \n ");
			return 0;
		}
		printf("Write 14443A 04 Data 00000000000000000000000000000000\n");											
		break;				

	case 12://Write 14443A Block Data					
		err = WriteMifareBlock("FFFFFFFFFFFF","04","12345678901234567890123456789012");
		if (err != 0)
		{
			printf("Write 14443A Block Fail ! \n ");
			return 0;
		}
		printf("Write 14443A 04 Data 12345678901234567890123456789012\n");											
		break;		

	case 13://Write UltraLight  Block Data					
		memset(Data32, 0x0, 64);  	
		err = RFID_WriteUltraLightBlock("07","12345678");
		if (err != 0)
		{
			printf("Write UltraLight Fail ! \n ");
			return 0;
		}
		printf("Write UltraLight 07 Data 12345678\n");											
		break;		

	case 14://Write UltraLight  Block Data					
		memset(Data32, 0x0, 64);  	
		err = RFID_WriteUltraLightBlock("07","00000000");
		if (err != 0)
		{
			printf("Write UltraLight Fail ! \n ");
			return 0;
		}
		printf("Write UltraLight 07 Data 00000000\n");											
		break;		

	case 15://Read UltraLight  Block Data					
		memset(Data, 0x0, 64);  	
		err = RFID_ReadUltraLightBlock("07",Data);
		if (err != 0)
		{
			printf("Read UltraLight Block Fail ! \n ");
			return 0;
		}
		printf("UltraLight 07 Data  : ");
		printf("%s\n", Data);							
		break;				

	case 16://Antenna ON							  	
		RFID_AntennaControl(1);										
		printf("Antenna ON\n");							
		break;						 

	case 17://Antenna OFF					  	
		RFID_AntennaControl(0);										
		printf("Antenna OFF\n");							
		break;				

	case 18://5 Secs Get 14443A UID					  	
		RFID_WorkingType(2,0);  //80 ms
		count = 0;
		for(i=0; i<50; i++)
		{
			memset(UID, 0x0, 16);  
			RFID_Get14443AUID(UID);   //350
			Time = Time+280;

			if (UID[0] != 0x0)
			{
				count++;
				printf("14443A UID : ");
				printf("%s     %d\n", UID,count);

				if (Time > 5000)
				{
					i=50;
					break;
				}

				for(j=0; j<50; j++)
				{
					//Err = CheckUid14443A(UID);
					//Time = Time+150;
					if (Err == 0)
					{
						count++;
						printf("14443A UID : ");
						printf("%s     %d\n", UID,count);
						if (Time > 5000)
						{
							i=50;					          
							j=50;
						}							  							  
					}
					else											
						j=50;
				}

				if (Time > 5000)
					break;
			}
		}

		break;		

	case 19://5 Secs TEST 14443A UID\Read\Write	

		Time=0;
		for(j=0; j<20; j++)
		{
			memset(UID, 0x0, 16);  	 
			RFID_OpenCard(UID);   
			Time= Time+300;
			if (UID[0] != 0x0)
			{		
				printf("14443A UID : ");
				printf("%s\n", UID);			 
				err = RFID_WriteMifareOneBlock(0,"FFFFFFFFFFFF","04","12345678901234567890123456789012",UID);
				Time= Time+660;
				printf("Write 14443A 04 Data 12345678901234567890123456789012\n");	
				memset(Data32, 0x0, 64);  	
				err = RFID_ReadMifareOneBlock(0,"FFFFFFFFFFFF","04",Data32,UID);
				Time= Time+360;
				if (err != 0)	
					printf("Read 14443A Block Fail ! \n ");
				else
				{
					printf("14443A 04 Data  : ");
					printf("%s\n", Data32);				
				}
				if (Data32[0] == 49 && Data32[1] == 50 && Data32[2] == 51 && Data32[3] == 52 && Data32[4] == 53 && Time<5000)
				{
					err = RFID_WriteMifareOneBlock(0,"FFFFFFFFFFFF","04","00000000000000000000000000000000",UID);
					Time= Time+660;
					printf("Write 14443A 04 Data 00000000000000000000000000000000\n");		
					memset(Data32, 0x0, 64);  	
					err = RFID_ReadMifareOneBlock(0,"FFFFFFFFFFFF","04",Data32,UID);
					Time= Time+360;
					if (err != 0)	
						printf("Read 14443A Block Fail ! \n ");			
					else
					{
						printf("14443A 04 Data  : ");
						printf("%s\n", Data32);				
					}		 
					if (Data32[0] == 48 && Data32[1] == 48 && Data32[2] == 48 && Data32[3] == 48 && Data32[4] == 48 && Time<5000)	
					{
						printf("Test PASS !  \n");
						return 0;
					}
				}						 
			}
			if (Time>5000)
				j = 20;
		} 
		printf("Test Fail !  \n");
		break;	



	case 20: // Write 15693 Block 01 Data 12345678	
		RFID_WorkingType(0,0);
		WriteSingleBlock("01","00",0,"12345678");	
		printf("WriteSingleBlock : 12345678 \n");
		break;

	case 21: // Write 15693 Block 01 Data 00000000
		RFID_WorkingType(0,0);
		WriteSingleBlock("01","00",0,"00000000");		
		printf("WriteSingleBlock : 00000000 \n");
		break;
	case 22: // Lock 15693 NXP Tag
		RFID_WorkingType(0,0);
		err = RFID_ISO15693LockBlock("00","00");
		if (err==0)
			printf("NXP Tag LOCK OK \n");
		else
			printf("NXP Tag LOCK Fail \n");

		break;
	case 23: // Lock 15693 Ti Tag
		RFID_WorkingType(0,0);
		err = RFID_ISO15693LockBlock("40","00");
		if (err==0)
			printf("Ti Tag LOCK OK \n");
		else
			printf("Ti Tag LOCK Fail \n");

		break;

	case 24: // Get UID 100 times
		RFID_WorkingType(1,0);
		int falseNum = 0;
		for(j=0; j<100; j++)
		{						
			memset(UID, 0x0, 24);  
			err = RFID_Get14443AUID(UID);
			printf("14443A UID : ");
			printf("%s  %d\n", UID,j+1);		
			if (err != 0)
				falseNum = falseNum +1;						
		}
		printf("false : %d\n",falseNum);						
		break;

	default:				
		printf("Error !\n ");
		break;				
	}			

	RFID_CloseReader();		

	return 0;

}


