#!/bin/sh

### Beginning: Launch eGTouchD daemon while setup boot-up ###
/usr/bin/eGTouchD
### End: Launch eGTouchD daemon while setup boot-up ###
exit 0
